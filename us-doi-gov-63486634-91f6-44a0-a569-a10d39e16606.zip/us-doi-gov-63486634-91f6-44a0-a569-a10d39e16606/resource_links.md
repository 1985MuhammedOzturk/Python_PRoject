## Resource links in dataset 

Listed below are useful links in this dataset : 

* Link(https://mrdata.usgs.gov/wfs/active-mines?request=getcapabilities&service=WFS&version=1.0.0&)
* Link(https://mrdata.usgs.gov/services/active-mines?request=getcapabilities&service=WMS&version=1.3.0&)
* Link(https://mrdata.usgs.gov/mineplant/)
